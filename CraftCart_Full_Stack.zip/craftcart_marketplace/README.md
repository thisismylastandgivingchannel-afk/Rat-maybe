# CraftCart full-stack marketplace

CraftCart is now a Node.js + Express + SQLite e-commerce starter. The front end remains split into `index.html`, `style.css`, and `script.js`.

## Features
- Customer registration, login, logout and persistent server-side sessions
- Password hashing with bcrypt
- SQLite database for users, products, orders, order items, payments and sessions
- Server-side order totals (prices are never trusted from the browser)
- Khalti ePayment (KPG-2): server-side initiate + server-side lookup verification
- Cash on delivery
- Customer order history
- Basic admin endpoints for listing orders and creating/updating products
- Rate limiting on authentication endpoints and secure HTTP headers

## Requirements
- Node.js 20 or newer
- A Khalti merchant account and secret key for online payments

## Run locally
1. Extract the ZIP and open the `craftcart_marketplace` folder in VS Code.
2. Install Node.js 20+ if it is not installed.
3. Open a terminal in this folder and run:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Set a long random `SESSION_SECRET`, and set `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`.
6. For Khalti sandbox testing, set `KHALTI_ENV=sandbox` and paste your sandbox merchant **secret key** into `KHALTI_SECRET_KEY`.
7. Run:
   ```bash
   npm start
   ```
8. Open http://localhost:3000

The SQLite database (`craftcart.sqlite`) and session database (`sessions.sqlite`) are created automatically.

## Khalti setup
- Register/sign in as a merchant in the Khalti test environment: https://dev.khalti.com/
- Copy the server-side secret key into `.env`. Never put this key in `script.js`, HTML, or any public repository.
- Keep `KHALTI_ENV=sandbox` while testing. Khalti sandbox test accounts and OTP information are in the official documentation.
- For production, complete Khalti merchant onboarding/KYC, set `KHALTI_ENV=production`, use the production secret key, and set `BASE_URL` to your deployed HTTPS domain.
- The app redirects customers to Khalti and checks the returned `pidx` with Khalti's server-side lookup API. It only marks an order paid when Khalti reports `Completed` and the amount matches the order total.

Official docs: https://docs.khalti.com/khalti-epayment/ and https://docs.khalti.com/getting-started/

## Admin
The first admin account is created at startup when `ADMIN_EMAIL` and `ADMIN_PASSWORD` are set and that email does not already exist. Admin endpoints:
- `GET /api/admin/orders`
- `POST /api/admin/products`
- `PATCH /api/admin/products/:id` (change `price` and/or `active`)

These are API endpoints; a dedicated visual admin dashboard is not included yet.

## Important production checklist
- Deploy behind HTTPS and set `NODE_ENV=production`.
- Set `BASE_URL` to the public HTTPS domain.
- Use a strong unique `SESSION_SECRET`; do not commit `.env` or database files.
- Use a managed persistent disk/managed database and backups. SQLite is suitable for a small starter, but a larger marketplace should migrate to PostgreSQL.
- Add CSRF protection, email verification, password reset, inventory reservation, shipping/tax rules, refunds, audit logs and monitoring before accepting real customer traffic at scale.
- Configure your hosting platform to persist the SQLite database. Ephemeral hosting storage will lose the database on redeploy.
- Never trust a payment success query parameter; this starter verifies payment server-to-server before changing order status.

This is a working integration starter, not a merchant account or a live payment approval. Actual payments require your own Khalti merchant approval and valid keys.
