let products = [
 {id:1,name:"Velocity Runner Sneakers",category:"Fashion",vendor:"North Street",price:2499,old:3299,rating:"4.9",tag:"Trending",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&auto=format&fit=crop&q=85",desc:"Lightweight everyday sneakers with a bold, comfortable fit."},
 {id:2,name:"Minimal Ceramic Watch",category:"Accessories",vendor:"Minute Studio",price:1899,old:2499,rating:"4.8",tag:"New",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&auto=format&fit=crop&q=85",desc:"A clean, minimal watch designed to go with everything."},
 {id:3,name:"Studio Wireless Headphones",category:"Electronics",vendor:"Sound Lab",price:3499,old:4299,rating:"4.7",tag:"Trending",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&auto=format&fit=crop&q=85",desc:"Rich sound and a comfortable over-ear design."},
 {id:4,name:"Everyday Carry Backpack",category:"Fashion",vendor:"Roam Goods",price:2199,old:2799,rating:"4.9",tag:"New",image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=85",desc:"A versatile backpack for work, class and weekend trips."},
 {id:5,name:"Glow Care Essentials Set",category:"Beauty",vendor:"Kind Skin",price:1599,old:1999,rating:"4.8",tag:"Trending",image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=700&auto=format&fit=crop&q=85",desc:"A simple self-care set for your daily routine."},
 {id:6,name:"Modern Table Lamp",category:"Home",vendor:"Forma Living",price:2799,old:3499,rating:"4.6",tag:"New",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700&auto=format&fit=crop&q=85",desc:"Warm ambient lighting with a timeless silhouette."},
 {id:7,name:"Classic Leather Wallet",category:"Accessories",vendor:"North Street",price:999,old:1399,rating:"4.7",tag:"Trending",image:"https://images.unsplash.com/photo-1627123424574-724758594e93?w=700&auto=format&fit=crop&q=85",desc:"A slim everyday wallet with room for the essentials."},
 {id:8,name:"Trail Outdoor Bottle",category:"Sports",vendor:"Peak Supply",price:799,old:1099,rating:"4.8",tag:"New",image:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=700&auto=format&fit=crop&q=85",desc:"Reusable insulated bottle for commutes and adventures."}
];
const categories=[["Fashion","👟","240+ items"],["Electronics","🎧","180+ items"],["Beauty","✳","95+ items"],["Home","⌂","130+ items"],["Accessories","◈","210+ items"],["Sports","⚡","75+ items"]];
let cart=JSON.parse(localStorage.getItem("craftcart-cart")||"[]"), activeFilter="all", searchTerm="", categoryFilter="all";
let currentUser=null, authMode="login", continueToCheckout=false;
const api=(url,options={})=>fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
const $=id=>document.getElementById(id), money=n=>"Rs. "+Number(n).toLocaleString("en-IN");
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove("show"),2400)}
function saveCart(){localStorage.setItem("craftcart-cart",JSON.stringify(cart));renderCart()}
function renderCategories(){
 $("categoryGrid").innerHTML=categories.slice(0,5).map(c=>`<button class="category-card" data-category="${c[0]}"><span class="category-icon">${c[1]}</span><span><strong>${c[0]}</strong><small>${c[2]}</small></span></button>`).join("");
 $("categorySelect").innerHTML='<option value="all">All categories</option>'+categories.map(c=>`<option value="${c[0]}">${c[0]}</option>`).join("");
 document.querySelectorAll(".category-card").forEach(b=>b.onclick=()=>{categoryFilter=b.dataset.category;$("categorySelect").value=categoryFilter;renderProducts();$("products").scrollIntoView({behavior:"smooth"})});
}
function renderProducts(){
 const filtered=products.filter(p=>(activeFilter==="all"||p.tag===activeFilter)&& (categoryFilter==="all"||p.category===categoryFilter)&&(`${p.name} ${p.category} ${p.vendor}`.toLowerCase().includes(searchTerm)));
 $("productGrid").innerHTML=filtered.map(p=>`<article class="product-card" data-id="${p.id}"><div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/600x600/f2f2ed/5d665e?text=Product+Image'"><span class="product-tag">${p.tag==="New"?"JUST IN":p.tag.toUpperCase()}</span><button class="heart" aria-label="Add ${p.name} to wishlist" data-heart="${p.id}">♡</button></div><div class="product-info"><div class="product-vendor">${p.vendor} · ${p.category}</div><h3>${p.name}</h3><div class="product-meta"><div><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span></div><span class="rating">★ ${p.rating}</span></div></div></article>`).join("");
 $("emptyState").classList.toggle("hidden",filtered.length>0);
 document.querySelectorAll(".product-card").forEach(card=>card.addEventListener("click",e=>{if(!e.target.closest(".heart"))openProduct(Number(card.dataset.id))}));
 document.querySelectorAll("[data-heart]").forEach(b=>b.onclick=e=>{e.stopPropagation();b.textContent=b.textContent==="♡"?"♥":"♡";toast(b.textContent==="♥"?"Added to wishlist (demo)":"Removed from wishlist")});
}
function openProduct(id){const p=products.find(x=>x.id===id);$("productModalContent").innerHTML=`<div class="product-detail"><img src="${p.image}" alt="${p.name}"><div><span class="eyebrow">${p.vendor} · ${p.category}</span><h2>${p.name}</h2><div class="rating">★ ${p.rating} customer rating</div><p>${p.desc}</p><div class="price">${money(p.price)} <span class="old-price">${money(p.old)}</span></div><button class="btn btn-dark full" id="detailAdd">Add to cart →</button></div></div>`;$("productModal").classList.remove("hidden");$("overlay").classList.remove("hidden");$("detailAdd").onclick=()=>{addToCart(id);closeModals()}}
function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();toast("Added to your cart")}
function renderCart(){
 $("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 if(!cart.length){$("cartItems").innerHTML='<div class="empty-cart">Your cart is looking a little empty.<br>Find something you love.</div>'}
 else $("cartItems").innerHTML=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-row"><img src="${p.image}" alt=""><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="qty"><button data-dec="${p.id}">−</button><span>${x.qty}</span><button data-inc="${p.id}">+</button></div></div><button class="remove" data-remove="${p.id}">×</button></div>`}).join("");
 const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);$("subtotal").textContent=money(total);$("checkoutTotal").textContent=money(total);
 document.querySelectorAll("[data-inc]").forEach(b=>b.onclick=()=>{cart.find(x=>x.id===+b.dataset.inc).qty++;saveCart()});
 document.querySelectorAll("[data-dec]").forEach(b=>b.onclick=()=>{const i=cart.find(x=>x.id===+b.dataset.dec);i.qty--;if(i.qty<=0)cart=cart.filter(x=>x.id!==i.id);saveCart()});
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart=cart.filter(x=>x.id!==+b.dataset.remove);saveCart()});
}
function showCart(){$("cartDrawer").classList.remove("hidden");$("overlay").classList.remove("hidden")}
function closeCart(){$("cartDrawer").classList.add("hidden");if($("productModal").classList.contains("hidden")&&$("checkoutModal").classList.contains("hidden")&&$("sellerModal").classList.contains("hidden"))$("overlay").classList.add("hidden")}
function closeModals(){document.querySelectorAll(".modal").forEach(m=>m.classList.add("hidden"));if($("cartDrawer").classList.contains("hidden"))$("overlay").classList.add("hidden")}
$("searchForm").onsubmit=e=>{e.preventDefault();searchTerm=$("searchInput").value.trim().toLowerCase();categoryFilter=$("categorySelect").value;renderProducts();$("products").scrollIntoView({behavior:"smooth"})};
$("categorySelect").onchange=()=>{categoryFilter=$("categorySelect").value;renderProducts()};
$("filterPills").onclick=e=>{const b=e.target.closest("button[data-filter]");if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll("#filterPills button").forEach(x=>x.classList.toggle("active",x===b));renderProducts()};
$("cartBtn").onclick=showCart;$("closeCart").onclick=closeCart;$("overlay").onclick=()=>{closeCart();closeModals()};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=closeModals);
$("checkoutBtn").onclick=()=>{if(!cart.length){toast("Your cart is empty");return}closeCart();if(!currentUser){continueToCheckout=true;openAuth("login");toast("Log in or create an account to continue.");return}$("checkoutModal").classList.remove("hidden");$("overlay").classList.remove("hidden")};
$("checkoutForm").onsubmit=async e=>{
 e.preventDefault(); if(!currentUser){closeModals();openAuth("login");toast("Please log in before checkout.");return}
 const d=new FormData(e.target), submit=e.target.querySelector('button[type="submit"]');
 const payload={customer:{name:d.get("name"),phone:d.get("phone"),address:d.get("address")},paymentMethod:d.get("payment"),items:cart.map(x=>({productId:x.id,quantity:x.qty}))};
 submit.disabled=true;submit.textContent="Creating secure order…";
 try{const r=await api("/api/orders",{method:"POST",body:JSON.stringify(payload)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Could not place order.");
  if(data.paymentUrl){toast("Redirecting to Khalti…");window.location.href=data.paymentUrl;return}
  cart=[];saveCart();closeModals();e.target.reset();toast(`Order #${data.orderId} placed. Pay on delivery.`);
 }catch(err){toast(err.message)}finally{submit.disabled=false;submit.textContent="Place order securely →"}
};
$("sellerBtn").onclick=()=>{$("sellerModal").classList.remove("hidden");$("overlay").classList.remove("hidden")};
$("sellerForm").onsubmit=e=>{e.preventDefault();const d=new FormData(e.target);toast(`Thanks ${d.get("name")}! Demo seller inquiry received.`);e.target.reset();closeModals()};
function openAuth(mode="login"){$("authModal").classList.remove("hidden");$("overlay").classList.remove("hidden");setAuthMode(mode)}
function setAuthMode(mode){authMode=mode;$("authTitle").textContent=mode==="register"?"Create your account":"Welcome back";$("authDescription").textContent=mode==="register"?"Create an account to shop and track orders.":"Log in to manage your orders.";$("authNameWrap").classList.toggle("hidden",mode!=="register");$("authNameWrap").querySelector("input").required=mode==="register";$("authSubmit").textContent=mode==="register"?"Create account →":"Log in →";$("authSwitch").classList.remove("hidden");$("authSwitch").innerHTML=mode==="register"?'Already have an account? <button type="button" id="toggleAuth">Log in</button>':'New to CraftCart? <button type="button" id="toggleAuth">Create account</button>';$("toggleAuth").onclick=()=>setAuthMode(mode==="register"?"login":"register");$("authForm").classList.remove("hidden");$("accountPanel").classList.add("hidden")}
function updateAccountUI(){ $("accountLabel").textContent=currentUser?currentUser.name.split(" ")[0]:"Account"; }
async function loadSession(){try{const r=await api("/api/auth/me");const d=await r.json();currentUser=d.user;updateAccountUI()}catch(e){console.warn(e)}}
$("authForm").onsubmit=async e=>{e.preventDefault();const d=new FormData(e.target);const body={email:d.get("email"),password:d.get("password")};if(authMode==="register")body.name=d.get("name");const b=$("authSubmit");b.disabled=true;try{const r=await api(`/api/auth/${authMode}`,{method:"POST",body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Authentication failed.");currentUser=data.user;updateAccountUI();closeModals();e.target.reset();toast(`Welcome${currentUser.name?", "+currentUser.name:""}!`);if(continueToCheckout){continueToCheckout=false;$("checkoutModal").classList.remove("hidden");$("overlay").classList.remove("hidden")}}catch(err){toast(err.message)}finally{b.disabled=false}};
$("accountBtn").onclick=()=>{openAuth("login");if(currentUser){$("authForm").classList.add("hidden");$("authTitle").textContent="Your account";$("authDescription").textContent="You are signed in.";$("authSwitch").classList.add("hidden");$("accountPanel").classList.remove("hidden");$("accountWelcome").textContent=`Signed in as ${currentUser.name} (${currentUser.email})`}};
$("ordersBtn").onclick=async()=>{try{const r=await api("/api/orders");const orders=await r.json();$("myOrders").innerHTML=orders.length?orders.map(o=>`<div class="order-card"><strong>Order #${o.id} · ${money(o.total)}</strong><small>${o.status} · ${new Date(o.created_at+"Z").toLocaleString()}</small><small>${o.items.map(i=>`${i.product_name} × ${i.quantity}`).join(", ")}</small></div>`).join(""):'<p class="muted">No orders yet.</p>'}catch(e){toast(e.message)}};
$("logoutBtn").onclick=async()=>{await api("/api/auth/logout",{method:"POST"});currentUser=null;updateAccountUI();closeModals();toast("You have logged out.")};
async function init(){try{const r=await api("/api/products");if(r.ok){const data=await r.json();if(data.length)products=data}}catch(e){console.warn("Using demo product data",e)}renderCategories();renderProducts();renderCart();await loadSession();const params=new URLSearchParams(location.search);if(params.has("payment")){const status=params.get("payment");toast(status==="success"?"Payment verified! Your order is confirmed.":"Payment was not completed. Check your orders before retrying.");history.replaceState({},"",location.pathname)}}
init();
