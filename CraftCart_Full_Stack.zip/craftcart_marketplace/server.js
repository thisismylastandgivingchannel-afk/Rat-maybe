require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const isProduction = process.env.NODE_ENV === 'production';
const khaltiBase = process.env.KHALTI_ENV === 'production' ? 'https://khalti.com/api/v2' : 'https://dev.khalti.com/api/v2';
const db = new Database(path.join(__dirname, 'craftcart.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, vendor TEXT NOT NULL,
 price INTEGER NOT NULL, old_price INTEGER NOT NULL, rating TEXT NOT NULL, tag TEXT NOT NULL,
 image TEXT NOT NULL, description TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
 total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', payment_method TEXT NOT NULL,
 customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id),
 product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
 unit_price INTEGER NOT NULL, quantity INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id),
 provider TEXT NOT NULL, pidx TEXT UNIQUE, transaction_id TEXT, amount_paisa INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'Initiated', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const seedProducts = [
 [1,'Velocity Runner Sneakers','Fashion','North Street',2499,3299,'4.9','Trending','https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&auto=format&fit=crop&q=85','Lightweight everyday sneakers with a bold, comfortable fit.'],
 [2,'Minimal Ceramic Watch','Accessories','Minute Studio',1899,2499,'4.8','New','https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&auto=format&fit=crop&q=85','A clean, minimal watch designed to go with everything.'],
 [3,'Studio Wireless Headphones','Electronics','Sound Lab',3499,4299,'4.7','Trending','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700&auto=format&fit=crop&q=85','Rich sound and a comfortable over-ear design.'],
 [4,'Everyday Carry Backpack','Fashion','Roam Goods',2199,2799,'4.9','New','https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=85','A versatile backpack for work, class and weekend trips.'],
 [5,'Glow Care Essentials Set','Beauty','Kind Skin',1599,1999,'4.8','Trending','https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=700&auto=format&fit=crop&q=85','A simple self-care set for your daily routine.'],
 [6,'Modern Table Lamp','Home','Forma Living',2799,3499,'4.6','New','https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700&auto=format&fit=crop&q=85','Warm ambient lighting with a timeless silhouette.'],
 [7,'Classic Leather Wallet','Accessories','North Street',999,1399,'4.7','Trending','https://images.unsplash.com/photo-1627123424574-724758594e93?w=700&auto=format&fit=crop&q=85','A slim everyday wallet with room for the essentials.'],
 [8,'Trail Outdoor Bottle','Sports','Peak Supply',799,1099,'4.8','New','https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=700&auto=format&fit=crop&q=85','Reusable insulated bottle for commutes and adventures.']
];
const insertProduct = db.prepare(`INSERT OR IGNORE INTO products (id,name,category,vendor,price,old_price,rating,tag,image,description) VALUES (?,?,?,?,?,?,?,?,?,?)`);
seedProducts.forEach(p => insertProduct.run(...p));

if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
 const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(process.env.ADMIN_EMAIL.toLowerCase());
 if (!existing) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
  db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')").run('CraftCart Admin', process.env.ADMIN_EMAIL.toLowerCase(), hash);
  console.log(`Admin account created for ${process.env.ADMIN_EMAIL}`);
 }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
 store: new SQLiteStore({ db: 'sessions.sqlite', dir: __dirname }),
 name: 'craftcart.sid', secret: process.env.SESSION_SECRET || 'development-only-change-this-secret',
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname)));

const publicUser = user => ({ id: user.id, name: user.name, email: user.email, role: user.role });
function requireAuth(req, res, next) { if (!req.session.user) return res.status(401).json({ error: 'Please log in first.' }); next(); }
function requireAdmin(req, res, next) { if (!req.session.user || req.session.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' }); next(); }
function validText(v, max=300) { return typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max; }

app.get('/api/health', (req,res) => res.json({ ok:true }));
app.get('/api/products', (req,res) => {
 const rows = db.prepare('SELECT id,name,category,vendor,price,old_price AS old,rating,tag,image,description AS desc FROM products WHERE active=1 ORDER BY id').all();
 res.json(rows);
});
app.post('/api/auth/register', async (req,res) => {
 const { name, email, password } = req.body || {};
 if (!validText(name,80) || !validText(email,160) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof password !== 'string' || password.length < 8 || password.length > 100)
  return res.status(400).json({ error: 'Enter a valid name/email and a password of at least 8 characters.' });
 const normalized = email.trim().toLowerCase();
 try {
  const hash = await bcrypt.hash(password, 12);
  const result = db.prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)').run(name.trim(), normalized, hash);
  req.session.user = { id: Number(result.lastInsertRowid), name: name.trim(), email: normalized, role: 'customer' };
  res.status(201).json({ user: publicUser(req.session.user) });
 } catch (e) { if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'An account with this email already exists.' }); throw e; }
});
app.post('/api/auth/login', async (req,res) => {
 const { email, password } = req.body || {};
 if (!validText(email,160) || typeof password !== 'string') return res.status(400).json({ error: 'Enter your email and password.' });
 const user = db.prepare('SELECT * FROM users WHERE email=?').get(email.trim().toLowerCase());
 if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
 req.session.regenerate(err => { if (err) return res.status(500).json({ error: 'Could not start session.' }); req.session.user = publicUser(user); req.session.save(() => res.json({ user: req.session.user })); });
});
app.post('/api/auth/logout', (req,res) => req.session.destroy(() => { res.clearCookie('craftcart.sid'); res.json({ ok:true }); }));
app.get('/api/auth/me', (req,res) => res.json({ user: req.session.user || null }));

app.post('/api/orders', requireAuth, async (req,res) => {
 const { items, customer, paymentMethod } = req.body || {};
 if (!Array.isArray(items) || !items.length || items.length > 50) return res.status(400).json({ error: 'Your cart is empty or invalid.' });
 if (!customer || !validText(customer.name,100) || !validText(customer.phone,30) || !validText(customer.address,500)) return res.status(400).json({ error: 'Complete your delivery details.' });
 if (!['khalti','cod'].includes(paymentMethod)) return res.status(400).json({ error: 'Choose a valid payment method.' });
 if (paymentMethod === 'khalti' && (!process.env.KHALTI_SECRET_KEY || process.env.KHALTI_SECRET_KEY.includes('your_khalti'))) return res.status(503).json({ error:'Khalti is not configured yet. Add your merchant secret key to .env, then restart the server.' });
 const normalized = new Map();
 for (const item of items) {
  const id = Number(item.productId), qty = Number(item.quantity);
  if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 20) return res.status(400).json({ error: 'Invalid cart item.' });
  normalized.set(id, (normalized.get(id) || 0) + qty);
 }
 const productRows = [...normalized.entries()].map(([id,qty]) => ({ product: db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(id), qty }));
 if (productRows.some(x => !x.product)) return res.status(400).json({ error: 'A product in your cart is no longer available.' });
 const total = productRows.reduce((sum,x) => sum + x.product.price * x.qty, 0);
 if (total < 10) return res.status(400).json({ error: 'Order total must be at least Rs. 10.' });
 const createOrder = db.transaction(() => {
  const r = db.prepare('INSERT INTO orders (user_id,total,status,payment_method,customer_name,phone,address) VALUES (?,?,?,?,?,?,?)')
   .run(req.session.user.id,total,paymentMethod === 'cod' ? 'placed' : 'awaiting_payment',paymentMethod,customer.name.trim(),customer.phone.trim(),customer.address.trim());
  const orderId = Number(r.lastInsertRowid);
  const add = db.prepare('INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity) VALUES (?,?,?,?,?)');
  productRows.forEach(x => add.run(orderId,x.product.id,x.product.name,x.product.price,x.qty));
  return orderId;
 });
 const orderId = createOrder();
 if (paymentMethod === 'cod') return res.status(201).json({ orderId, status:'placed', message:'Order placed. Pay on delivery.' });
 const pidxRef = `CC-${orderId}-${crypto.randomBytes(4).toString('hex')}`;
 try {
  const response = await fetch(`${khaltiBase}/epayment/initiate/`, {
   method:'POST', headers:{ Authorization:`Key ${process.env.KHALTI_SECRET_KEY}`, 'Content-Type':'application/json' },
   body:JSON.stringify({ return_url:`${BASE_URL}/api/payments/khalti/callback`, website_url:BASE_URL, amount:total*100, purchase_order_id:pidxRef, purchase_order_name:`CraftCart order #${orderId}`, customer_info:{ name:customer.name.trim(), email:req.session.user.email, phone:customer.phone.trim() } })
  });
  const data = await response.json();
  if (!response.ok || !data.pidx || !data.payment_url) throw new Error(data.detail || data.message || 'Khalti did not accept the payment request.');
  db.prepare('INSERT INTO payments (order_id,provider,pidx,amount_paisa,status) VALUES (?,?,?,?,?)').run(orderId,'khalti',data.pidx,total*100,'Initiated');
  res.status(201).json({ orderId, paymentUrl:data.payment_url, status:'initiated' });
 } catch (e) {
  db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(orderId);
  res.status(502).json({ error:`Could not start Khalti payment: ${e.message}` });
 }
});

app.get('/api/payments/khalti/callback', async (req,res) => {
 const pidx = String(req.query.pidx || '');
 const payment = db.prepare('SELECT payments.*,orders.total FROM payments JOIN orders ON orders.id=payments.order_id WHERE payments.pidx=?').get(pidx);
 if (!payment || !process.env.KHALTI_SECRET_KEY) return res.redirect('/?payment=not-found');
 try {
  const response = await fetch(`${khaltiBase}/epayment/lookup/`, { method:'POST', headers:{ Authorization:`Key ${process.env.KHALTI_SECRET_KEY}`, 'Content-Type':'application/json' }, body:JSON.stringify({ pidx }) });
  const data = await response.json();
  const valid = response.ok && data.status === 'Completed' && Number(data.total_amount) === payment.amount_paisa && payment.amount_paisa === payment.total * 100;
  db.prepare('UPDATE payments SET status=?, transaction_id=? WHERE pidx=?').run(data.status || 'Verification failed',data.transaction_id || null,pidx);
  if (valid) {
   db.prepare("UPDATE orders SET status='paid' WHERE id=?").run(payment.order_id);
   return res.redirect('/?payment=success');
  }
  db.prepare("UPDATE orders SET status='payment_pending' WHERE id=?").run(payment.order_id);
  return res.redirect('/?payment=not-completed');
 } catch (e) { console.error('Khalti lookup failed:',e.message); return res.redirect('/?payment=verification-error'); }
});

app.get('/api/orders', requireAuth, (req,res) => {
 const orders = db.prepare('SELECT id,total,status,payment_method,created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(req.session.user.id);
 const items = db.prepare('SELECT product_name,unit_price,quantity FROM order_items WHERE order_id=?');
 res.json(orders.map(o => ({ ...o, items:items.all(o.id) })));
});
app.get('/api/admin/orders', requireAdmin, (req,res) => res.json(db.prepare(`SELECT orders.*,users.email FROM orders JOIN users ON users.id=orders.user_id ORDER BY orders.id DESC`).all()));
app.post('/api/admin/products', requireAdmin, (req,res) => {
 const p=req.body||{};
 if (!validText(p.name,150)||!validText(p.category,60)||!validText(p.vendor,100)||!Number.isInteger(Number(p.price))||Number(p.price)<1||!validText(p.image,1000)||!validText(p.description,1000)) return res.status(400).json({error:'Invalid product details.'});
 const r=db.prepare('INSERT INTO products (name,category,vendor,price,old_price,rating,tag,image,description) VALUES (?,?,?,?,?,?,?,?,?)').run(p.name,p.category,p.vendor,Number(p.price),Number(p.oldPrice||p.price),String(p.rating||'New'),String(p.tag||'New'),p.image,p.description);
 res.status(201).json({id:Number(r.lastInsertRowid)});
});
app.patch('/api/admin/products/:id', requireAdmin, (req,res) => {
 const {price,active}=req.body||{};
 if (price!==undefined && (!Number.isInteger(Number(price))||Number(price)<1)) return res.status(400).json({error:'Invalid price.'});
 const row=db.prepare('SELECT id FROM products WHERE id=?').get(Number(req.params.id)); if(!row)return res.status(404).json({error:'Product not found.'});
 if(price!==undefined)db.prepare('UPDATE products SET price=? WHERE id=?').run(Number(price),row.id);
 if(active!==undefined)db.prepare('UPDATE products SET active=? WHERE id=?').run(active?1:0,row.id);
 res.json({ok:true});
});

app.get('*', (req,res) => res.sendFile(path.join(__dirname,'index.html')));
app.use((err,req,res,next) => { console.error(err); res.status(500).json({error:'Server error. Please try again.'}); });
app.listen(PORT, () => console.log(`CraftCart running at ${BASE_URL}`));
